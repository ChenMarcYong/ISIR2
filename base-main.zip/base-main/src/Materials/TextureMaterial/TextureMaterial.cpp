
#include "TextureMaterial.h"
#include "Node.h"
#include <glm/gtc/type_ptr.hpp>


TextureMaterial::TextureMaterial(std::string name,Texture2D* cTex1,  Texture2D* nTex) :
	MaterialGL(name)
{


	Tex = cTex1;
	TexN = nTex;
	


	vp = new GLProgram(MaterialPath + "TextureMaterial/TextureMaterial-VS.glsl", GL_VERTEX_SHADER);
	fp = new GLProgram(MaterialPath + "TextureMaterial/TextureMaterial-FS.glsl", GL_FRAGMENT_SHADER);

	m_ProgramPipeline->useProgramStage(vp, GL_VERTEX_SHADER_BIT);
	m_ProgramPipeline->useProgramStage(fp, GL_FRAGMENT_SHADER_BIT);

	m_ProgramPipeline->link();

	l_View = glGetUniformLocation(vp->getId(), "View");
	l_Proj = glGetUniformLocation(vp->getId(), "Proj");
	l_Model = glGetUniformLocation(vp->getId(), "Model");
	l_PosLum = glGetUniformLocation(vp->getId(), "PosLum");
	l_PosCam = glGetUniformLocation(vp->getId(), "PosCam");

	/*******MODE BINDLESS******/
	
	/*l_Texture = glGetUniformLocation(fp->getId(), "ColorTex");
	glProgramUniformHandleui64ARB(fp->getId(), l_Texture, cTex1->getHandle());
	glProgramUniformHandleui64ARB(fp->getId(), glGetUniformLocation(fp->getId(), "ColorTex2") , cTex2->getHandle());
	glProgramUniformHandleui64ARB(fp->getId(), glGetUniformLocation(fp->getId(), "NormalTex"), nTex->getHandle());*/
	
	/*******MODE INDIRECT******/

	glProgramUniform1i(fp->getId(), glGetUniformLocation(fp->getId(), "ColorTex"), 0);


	glProgramUniform1i(fp->getId(), glGetUniformLocation(fp->getId(), "NormalTex"), 2);
	/**************************/

	l_Phong = glGetUniformLocation(fp->getId(), "Phong");
	l_Albedo = glGetUniformLocation(fp->getId(), "Albedo");


	param.albedo = glm::vec3(0.2, 0.7, 0.8);
	param.coeff = glm::vec4(0.2,0.8,1.0,100.0);



	updatePhong();
}

TextureMaterial::~TextureMaterial()
{

}

void TextureMaterial::render(Node* o)
{
	
	/*******MODE INDIRECT******/
	glBindTextureUnit(0, Tex->getId());
	glBindTextureUnit(2, TexN->getId());
		/*************************/


	m_ProgramPipeline->bind();
	o->drawGeometry(GL_TRIANGLES);
	m_ProgramPipeline->release();

	


}
void TextureMaterial::animate(Node* o, const float elapsedTime)
{

	glm::mat4 proj = Scene::getInstance()->camera()->getProjectionMatrix();
	glm::mat4 view = Scene::getInstance()->camera()->getViewMatrix();

	glProgramUniformMatrix4fv(vp->getId(), l_View, 1, GL_FALSE, glm::value_ptr(view));
	glProgramUniformMatrix4fv(vp->getId(), l_Proj, 1, GL_FALSE, glm::value_ptr(proj));
	glProgramUniformMatrix4fv(vp->getId(), l_Model, 1, GL_FALSE, glm::value_ptr(o->frame()->getModelMatrix()));

	glProgramUniform3fv(vp->getId(), l_PosLum, 1,  glm::value_ptr(Scene::getInstance()->getNode("Light")->frame()->convertPtTo(glm::vec3(0.0,0.0,0.0),o->frame())));

	glProgramUniform3fv(vp->getId(), l_PosCam, 1, glm::value_ptr(Scene::getInstance()->camera()->frame()->convertPtTo(glm::vec3(0.0, 0.0, 0.0), o->frame())));

}


void TextureMaterial::updatePhong()
{
	glProgramUniform4fv(fp->getId(), l_Phong, 1, glm::value_ptr(glm::vec4(param.coeff)));
	glProgramUniform3fv(fp->getId(), l_Albedo, 1, glm::value_ptr(param.albedo));
}





void TextureMaterial::displayInterface()
{
	

}




