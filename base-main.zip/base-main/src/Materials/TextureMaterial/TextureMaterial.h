

#ifndef _TextureMaterial_
#define _TextureMaterial_


#include "MaterialGL.h"


#include "Texture2D.h"

struct PhongTP4 {
	glm::vec4 coeff;
	glm::vec3 albedo;
};




class TextureMaterial : public MaterialGL
{
public:

	//Attributs

	//Constructeur-Destructeur

	/**
		Constructeur de la classe � partir du nom du mat�riau
		@param name : nom du mat�riau
	*/
	TextureMaterial(std::string name, Texture2D* cTex1,  Texture2D* nTex);

	/**
		Destructeur de la classe
	*/
	~TextureMaterial();

	//M�thodes

	/**
		M�thode virtuelle qui est appel�e pour faire le rendu d'un objet en utilisant ce mat�riau
		@param o : Node/Objet pour lequel on veut effectuer le rendu
	*/
	virtual void render(Node* o);

	/**
		M�thode virtuelle qui est appel�e pour modifier une valeur d'un param�tre n�cessaire pour le rendu
		@param o : Node/Objet concern� par le rendu
		@param elapsedTime : temps
	*/
	virtual void animate(Node* o, const float elapsedTime);



	 void updatePhong();

	virtual void displayInterface() ;


protected:
	GLProgram* vp;
	GLProgram* fp;

	GLuint l_View,l_Proj, l_Model, l_PosLum, l_PosCam,l_Phong,l_Albedo, l_Texture;
	PhongTP4 param;


	Texture2D* Tex,*TexN;

};

#endif